package kr.or.kosta.springmvc.aop.dao;

public interface PointDAO {

	public void updatePoint(String uno, int point) throws Exception;
	
}
