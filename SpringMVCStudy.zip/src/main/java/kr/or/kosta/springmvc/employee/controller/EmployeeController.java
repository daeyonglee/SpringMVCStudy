package kr.or.kosta.springmvc.employee.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.or.kosta.springmvc.employee.domain.Employee;
import kr.or.kosta.springmvc.user.domain.User;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

	Logger logger = Logger.getLogger(EmployeeController.class);

	/**
	 * 사원 목록 요청 처리
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(Model model) {
		logger.info("list() 실행됨...");
		
		String message = "사원 목록 페이지 동적데이터입니다.";
		model.addAttribute("message", message);
		return "/employee/list";
	}

	/**
	 * 사원 등록 화면 요청 처리
	 */
	@RequestMapping(value = "/regist", method = RequestMethod.GET)
	public void form() {
	}

	/**
	 * 사원 등록 요청 처리
	 */
	@RequestMapping(value = "/regist", method = RequestMethod.POST)
	public String regist(String firstName, String lastName) {
//	public String regist(Employee employee) {
		logger.info("전달받은 파라메터: " + firstName);
		logger.info("전달받은 파라메터: " + lastName);
//		logger.info("전달받은 객체: " + employee);
		return "/employee/result";
	}
	
	/**
	 * 사원 상세 요청 처리
	 */
	@RequestMapping("/view")
	public String view2(@RequestParam String id) {
		logger.info("전달받은 사원번호 : " + id);
		// 실제 디비 입력 처리
		return "/employee/view";
	}


	/**
	 * RESTfull 사원 상세 요청 처리
	 */
	@RequestMapping(value="/{id}", method = RequestMethod.GET)
	public String view(@PathVariable String id) {
		logger.info("전달받은 사원번호 : " + id);
		// 실제 디비 입력 처리
		return "/employee/view";
	}
	
	@RequestMapping(value="/", method = RequestMethod.GET)
	public String list2() {
		logger.info("사원목록 요청");
		return "/employee/list";
	}

	

	/**
	 * 사원 정보 수정 요청 처리
	 */
	@RequestMapping(value = "/edit", params = "type=admin")
	public void edit() {
		logger.info("어드민 요청");
	}

	/**
	 * 사원 정보 수정 요청 처리
	 */
	@RequestMapping(value = "/edit", params = "type=member")
	public void edit2() {
		logger.info("일반회원 요청 요청");
	}
	
	
	@RequestMapping("/sample")
	public void sample(HttpServletRequest request, HttpServletResponse response){
		logger.info(request.getRemoteAddr());
	}

	/**
	 * 브라우저 헤더정보 읽기
	 */
	@RequestMapping("/header")
	public void getHeader(@RequestHeader("user-agent") String userAgent) {
		logger.info("요청브라우저: " + userAgent);
	}

	/*
	 * 로그인 요청 처리
	 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(@RequestParam String id, @RequestParam String pw, HttpServletResponse response) {
		logger.info(id);
		logger.info(pw);
		// 회원이라 가정
		Cookie loginId = new Cookie("loginId", id);
		loginId.setPath("/");
		response.addCookie(loginId);
		// response.sendRedirect(arg0);
		return "redirect:/employee/usecookie";

	}

	/*
	 * 로그인 요청 처리
	 */
	@RequestMapping(value = "/usecookie", method = RequestMethod.GET)
	public void useCooke(@CookieValue("loginId") String loginId) {
		logger.info("로그인 아이디: " + loginId);
	}
	

	/** JSON 응답 처리 샘플1 - 비권장 */
	@RequestMapping("/json1")
	public void json1(Model model, PrintWriter out) {
		// JSON 전송
		String sampleJson = "{\"id\": \"bangry\", \"passwd\" : \"1234\", \"name\" : \"김기정\"}";
		out.println(sampleJson);
	}

	/** JSON 응답 처리 샘플2 - 권장 */
	/**
	 * @ResponseBody를 사용하면 해당 콘트롤러 메소드에서 리턴하는 값이 바로 응답 바디가 되므로 다른 뷰로 사용하지 않고도
	 *                간단한 응답을 클라이언트에게 직접 전송할 수 있다 주로 AJAX 요청에 대한 XML, JSON 응답 처리
	 *                시 사용 pom.xml에 jackson json 라이브러리 추가 필요
	 */
	@RequestMapping(value = "/json2", produces = "text/plain; charset=utf8")
	public @ResponseBody String json2(Model model) {
		String sampleJson = "{\"id\": \"bangry\", \"passwd\" : \"1234\", \"name\" : \"김기정\"}";
		return sampleJson;
	}

	/** JSON 응답 처리 샘플3 - 권장 */
	@RequestMapping(value = "/json3")
	public @ResponseBody User json3(Model model) {
		User user = new User("bangry1", "김기정1", "1111", "bangry313@naver.com");
		return user;
	}

	/** JSON 응답 처리 샘플4 - 권장 */
	@RequestMapping(value = "/json4")
	public @ResponseBody Map<String, Object> json4(Model model) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", "bangry");
		map.put("name", "김기정");
		map.put("passwd", "1234");
		map.put("address", "서울시 중랑구 신내로 128");
		return map;
	}

	/** JSON 응답 처리 샘플5 - 권장 */
	@RequestMapping(value = "/jsonList")
	public @ResponseBody List<User> json5(Model model) {
		// List<User> list = xxxService.list();
		List<User> list = new ArrayList<User>();
		list.add(new User("bangry1", "김기정1", "1111", "bangry313@naver.com"));
		list.add(new User("bangry2", "김기정2", "1111", "bangry313@naver.com"));
		list.add(new User("bangry3", "김기정3", "1111", "bangry313@naver.com"));
		return list;
	}

	@RequestMapping("/json5")
	public String json5() {
		return "/employee/sendJson";
	}

	@RequestMapping(value = "/json6", method = RequestMethod.POST)
	public @ResponseBody User json6(@RequestBody User user) {
		// 동적인 경우 Map으로..
		logger.debug("수신데이터: " + user);
		// 에코
		return user;
	}
}
